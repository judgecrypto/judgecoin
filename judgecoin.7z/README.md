
judgeCoin 

COIN SPECIFICATIONS
- Total coins: Estimated 15,000,000 Between PoW and PoS blocks 
- 500 Coins per PoW block 
- PoW Algorithm: X13 
- PoW + PoS Hybrid 
- PoW Blocks: 43200
- PoS interest 6% Annually 
- 24hr PoS min coin age 
- 60 second block target 
- 110 confirmations for blocks to mature

"Help support Judge Crypto by donating Judge Coin or Bitcoin. Your donation helps pay for coin related services, future developments, or sometimes just a reward for putting out a truly fair coin without a premine, instamine, or IPO."

